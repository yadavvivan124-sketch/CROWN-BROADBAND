# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Downloaded source notes

- The site logo is stored in Lovable's asset storage; the actual image is included at `src/assets/crown-logo.png`. Inside Lovable it is imported via `crown-logo.png.asset.json` and works as-is. To run the project outside Lovable, replace the asset import with a normal import: `import logo from "@/assets/crown-logo.png"` in `src/components/site/Nav.tsx` and `ContactFooter.tsx` (see how `favicon.png` is used in `src/routes/__root.tsx`).
- Run `bun install` (or `npm install`) then `bun run dev` to start the dev server.
