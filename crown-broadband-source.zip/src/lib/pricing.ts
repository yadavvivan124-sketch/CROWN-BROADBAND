export type PricingTier = {
  id: string;
  name: string;
  subscribers: string;
  maxUsers: number | null; // null = enterprise (2,000+)
  setup: string;
  monthly: string;
  note?: string;
};

export const TIERS: PricingTier[] = [
  {
    id: "starter",
    name: "Tier 1",
    subscribers: "Upto 400 Users",
    maxUsers: 400,
    setup: "₹6,000",
    monthly: "₹5,000",
    note: "one-time setup",
  },
  {
    id: "growth",
    name: "Tier 2",
    subscribers: "Upto 750 Users",
    maxUsers: 750,
    setup: "₹8,000",
    monthly: "₹7,000",
    note: "one-time setup",
  },
  {
    id: "scale",
    name: "Tier 3",
    subscribers: "Upto 1,000 Users",
    maxUsers: 1000,
    setup: "₹11,000",
    monthly: "₹10,000",
    note: "one-time setup",
  },
  {
    id: "pro",
    name: "Tier 4",
    subscribers: "Upto 2,000 Users",
    maxUsers: 2000,
    setup: "₹15,000",
    monthly: "₹14,000",
    note: "one-time setup",
  },
  {
    id: "enterprise",
    name: "Enterprise",
    subscribers: "2,000+ Users",
    maxUsers: null,
    setup: "₹30,000",
    monthly: "₹8",
    note: "per user / month",
  },
];

export const SLIDER_MIN = 400;
export const SLIDER_MAX = 2500;

export function recommendTier(subscribers: number): PricingTier {
  for (const tier of TIERS) {
    if (tier.maxUsers !== null && subscribers <= tier.maxUsers) return tier;
  }
  const last = TIERS[TIERS.length - 1];
  if (!last) throw new Error("Pricing tiers are misconfigured");
  return last;
}
