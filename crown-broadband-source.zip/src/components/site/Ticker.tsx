const ITEMS = [
  "Zero-touch provisioning",
  "Multi-vendor ONTs",
  "Remote reboot & diagnostics",
  "Firmware orchestration",
  "Bulk parameter push",
  "Real-time CPE telemetry",
  "TR-069/CWMP standard compliant",
];

export function Ticker() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="overflow-hidden border-y border-line-dark bg-navy py-3.5">
      <div className="animate-marquee flex w-max items-center">
        {row.map((item, i) => (
          <span key={i} className="flex items-center">
            <span className="mono-label whitespace-nowrap px-6 text-navy-muted">
              {item}
            </span>
            <span
              className="h-1 w-1 rounded-full bg-line-dark"
              aria-hidden="true"
            />
          </span>
        ))}
      </div>
    </div>
  );
}
