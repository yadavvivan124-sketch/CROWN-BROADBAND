import { ArrowRight, Mail, Phone } from "lucide-react";
import crownLogo from "@/assets/crown-logo.png.asset.json";

export function ContactFooter() {
  return (
    <>
      <section id="contact" className="scroll-mt-20 bg-background pb-20 md:pb-28">
        <div className="mx-auto max-w-6xl px-6">
          <div className="card-lift overflow-hidden rounded-xl border border-border bg-card">
            <div className="grid md:grid-cols-2">
              <div className="p-8 md:p-10">
                <p className="mono-label text-primary">Contact Sales</p>
                <h2 className="mt-3 text-2xl font-bold tracking-tight text-foreground md:text-3xl">
                  Talk to our engineers, not a sales script.
                </h2>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  Tell us about your network — subscriber count, CPE mix and
                  current pain points. We'll scope the right ACS plan and get
                  you migrating within days.
                </p>
                <a
                  href="mailto:crownbroadband.in@gmail.com"

                  className="mt-7 inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-colors duration-150 hover:bg-primary-hover"
                >
                  Request a Call Back
                  <ArrowRight className="h-4 w-4" />
                </a>
              </div>
              <div className="border-t border-border bg-secondary/60 p-8 md:border-l md:border-t-0 md:p-10">
                <dl className="space-y-6">
                  <div>
                    <dt className="mono-label text-muted-foreground">Email</dt>
                    <dd className="mt-1.5">
                      <a
                        href="mailto:crownbroadband.in@gmail.com"
                        className="inline-flex items-center gap-2 text-sm font-semibold text-foreground hover:text-primary"
                      >
                        <Mail className="h-4 w-4 text-primary" />
                        crownbroadband.in@gmail.com

                      </a>
                    </dd>
                  </div>
                  <div>
                    <dt className="mono-label text-muted-foreground">Support Phone</dt>
                    <dd className="mt-1.5">
                      <a
                        href="tel:+917011102373"
                        className="inline-flex items-center gap-2 text-sm font-semibold text-foreground hover:text-primary"
                      >
                        <Phone className="h-4 w-4 text-primary" />
                        +91 70111 02373

                      </a>
                    </dd>
                  </div>
                  <div>
                    <dt className="mono-label text-muted-foreground">Support Hours</dt>
                    <dd className="mt-1.5 text-sm font-medium text-foreground">
                      24×7 NOC escalation for active ISPs
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-border bg-background">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 sm:flex-row">
          <div className="flex items-center gap-3">
            <img src={crownLogo.url} alt="Crown Broadband" className="h-8 w-auto" />
          </div>
          <nav className="flex items-center gap-6" aria-label="Footer">
            {[
              ["Platform", "#platform"],
              ["Architecture", "#architecture"],
              ["Pricing", "#pricing"],
              ["Contact", "#contact"],
            ].map(([label, href]) => (
              <a
                key={href}
                href={href}
                className="text-[13px] font-medium text-muted-foreground transition-colors duration-150 hover:text-foreground"
              >
                {label}
              </a>
            ))}
          </nav>
          <p className="mono-label text-muted-foreground">
            © {new Date().getFullYear()} crownbroadband.in
          </p>
        </div>
      </footer>
    </>
  );
}
