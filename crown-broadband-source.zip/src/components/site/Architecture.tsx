import { Cpu, MonitorCog, Router, ShieldCheck } from "lucide-react";

const NODES = [
  {
    icon: Router,
    tag: "Node 01",
    title: "CPE Devices",
    body: "ONTs, modems & gateways in the field",
  },
  {
    icon: ShieldCheck,
    tag: "Node 02",
    title: "TR-069 / CWMP",
    body: "Inform sessions & RPCs over HTTPS",
  },
  {
    icon: Cpu,
    tag: "Node 03",
    title: "Crown ACS Engine",
    body: "Rules, provisioning & telemetry engine",
  },
  {
    icon: MonitorCog,
    tag: "Node 04",
    title: "ISP NOC",
    body: "Operators, dashboards & live escalations",
  },
];

export function Architecture() {
  return (
    <section
      id="architecture"
      className="scroll-mt-20 bg-navy py-20 text-navy-foreground md:py-28"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="mono-label text-primary">Architecture</p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
            From subscriber premises to your NOC, in one secure path.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-navy-muted">
            Every session is standards-based and encrypted end to end. Data
            flows in one direction — from the device, through the ACS engine,
            to the operators who need it.
          </p>
        </div>

        {/* Flow diagram */}
        <div className="mt-14 grid gap-4 lg:grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr] lg:items-stretch">
          {NODES.map((node, i) => (
            <div key={node.tag} className="contents">
              <div className="card-lift flex flex-col rounded-xl border border-line-dark bg-navy-2/60 p-5">
                <span className="flex h-10 w-10 items-center justify-center rounded-md border border-line-dark bg-white/5 text-primary animate-node-pulse" style={{ animationDelay: `${i * 0.9}s` }}>
                  <node.icon className="h-5 w-5" />
                </span>
                <p className="mono-label mt-4 text-navy-muted">{node.tag}</p>
                <h3 className="mt-1.5 text-base font-semibold">{node.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-navy-muted">
                  {node.body}
                </p>
              </div>
              {i < NODES.length - 1 && (
                <div
                  className="relative hidden h-full min-h-12 w-10 items-center lg:flex"
                  aria-hidden="true"
                >
                  <span className="absolute inset-x-0 top-1/2 h-px bg-line-dark" />
                  <span className="animate-flow-packet absolute top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-primary" style={{ animationDelay: `${i * 0.8}s` }} />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Protocol breakdown */}
        <div className="mt-14 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-line-dark bg-line-dark sm:grid-cols-2 lg:grid-cols-4">
          {PROTOCOLS.map((p) => (
            <div key={p.title} className="bg-navy p-6">
              <h3 className="text-sm font-semibold">{p.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-navy-muted">{p.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const PROTOCOLS = [
  {
    title: "TR-069 / CWMP",
    body: "Fully standards-compliant CPE WAN Management Protocol — no proprietary lock-in on either side.",
  },
  {
    title: "HTTPS Connection Requests",
    body: "The ACS reaches back to each CPE over authenticated TLS for re-provisioning and diagnostics.",
  },
  {
    title: "Multi-vendor compatibility",
    body: "Data models from every major ONT vendor normalised into one consistent inventory.",
  },
  {
    title: "Direct L2/L3 engineering access",
    body: "Escalations land with network engineers, not scripts — fixes ship from people who read the traces.",
  },
];
