import { CheckCircle2, Gauge, Headset, Layers, Network, ShieldCheck } from "lucide-react";

const INVENTORY = [
  { model: "Nokia XS-010X-Q", id: "ZGC2B3A7…", status: "Online" },
  { model: "TP-Link XZ000-C3", id: "TP8410Q1…", status: "Online" },
  { model: "Syrotech GPON", id: "SYR44C90…", status: "Rebooting" },
  { model: "Netlink HG323", id: "NLK7F12A…", status: "Online" },
];

const PROVISION_STEPS = [
  "PPPoE credentials applied",
  "SSID & Wi-Fi push",
  "VLAN tagging",
  "Management TR-069 endpoint",
];

const PROTOCOLS = [
  {
    icon: Network,
    title: "TR-069 / CWMP",
    body: "Standards-compliant provisioning — Inform sessions, RPCs and bulk parameter push over HTTPS.",
  },
  {
    icon: ShieldCheck,
    title: "HTTPS Connection Requests",
    body: "Every connection request and firmware push runs over authenticated TLS back to the CPE.",
  },
  {
    icon: Layers,
    title: "Multi-vendor compatibility",
    body: "Nokia, TP-Link, Syrotech, Netlink and more — GPON, EPON and Ethernet CPE as one fleet.",
  },
  {
    icon: Headset,
    title: "Direct L2/L3 engineering access",
    body: "Skip the ticket queue. Talk straight to network engineers who can act on your ACS data.",
  },
];

export function Platform() {
  return (
    <section id="platform" className="scroll-mt-20 bg-background py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="mono-label text-primary">Platform Capabilities</p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            One control plane for every CPE on your network.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            Zero-touch configuration from the moment an ONT powers on. Crown
            Broadband's ACS discovers, provisions and monitors every device —
            across vendors and technologies — from a single dashboard.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-12">
          {/* 1 — Custom ACS UI with live mini-dashboard */}
          <div className="card-lift rounded-xl border border-border bg-card p-6 lg:col-span-7">
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary-soft text-primary">
                <Gauge className="h-4.5 w-4.5" />
              </span>
              <h3 className="text-lg font-semibold text-foreground">
                Custom ACS UI
              </h3>
            </div>
            <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
              A purpose-built dashboard for ISP operations — ONT inventory,
              connection status and diagnostics at a glance.
            </p>

            <div className="mt-5 overflow-hidden rounded-lg border border-border">
              <div className="flex items-center justify-between border-b border-border bg-secondary/60 px-3.5 py-2">
                <span className="mono-label text-muted-foreground">ONT Inventory</span>
                <span className="mono-label text-muted-foreground">Status</span>
              </div>
              <div className="divide-y divide-border">
                {INVENTORY.map((row) => (
                  <div
                    key={row.id}
                    className="flex items-center justify-between px-3.5 py-2.5"
                  >
                    <span className="font-mono text-xs font-medium text-foreground">
                      {row.model}
                      <span className="ml-2 text-muted-foreground">{row.id}</span>
                    </span>
                    <span
                      className={`mono-label inline-flex items-center gap-1.5 ${
                        row.status === "Online" ? "text-success" : "text-primary"
                      }`}
                    >
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          row.status === "Online" ? "bg-success" : "bg-primary"
                        }`}
                      />
                      {row.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 2 — TR-069 / CWMP auto-provisioning */}
          <div className="card-lift rounded-xl border border-border bg-card p-6 lg:col-span-5">
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary-soft text-primary">
                <Network className="h-4.5 w-4.5" />
              </span>
              <h3 className="text-lg font-semibold text-foreground">
                TR-069 / CWMP Auto-Provisioning
              </h3>
            </div>
            <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
              Devices self-provision on first Inform. Push complete service
              profiles without touching a single ONT in the field.
            </p>
            <ul className="mt-5 space-y-3">
              {PROVISION_STEPS.map((step) => (
                <li key={step} className="flex items-center gap-2.5 text-sm font-medium text-foreground">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-success" />
                  {step}
                </li>
              ))}
            </ul>
          </div>

          {/* 3 — Dedicated technical support */}
          <div className="card-lift rounded-xl border border-border bg-card p-6 lg:col-span-5">
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary-soft text-primary">
                <Headset className="h-4.5 w-4.5" />
              </span>
              <h3 className="text-lg font-semibold text-foreground">
                Dedicated Technical Support
              </h3>
            </div>
            <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
              Engineers who know TR-069 inside out — on call for your NOC, not
              a generic helpdesk.
            </p>
            <div className="mt-5 rounded-lg border border-border bg-secondary/60 px-4 py-4">
              <div className="flex items-baseline justify-between">
                <span className="mono-label text-muted-foreground">Platform Uptime</span>
                <span className="font-mono text-2xl font-bold tabular-nums text-success">
                  99.99%
                </span>
              </div>
              <div className="mt-3 flex gap-1" aria-hidden="true">
                {Array.from({ length: 30 }).map((_, i) => (
                  <span
                    key={i}
                    className={`h-6 flex-1 rounded-[2px] ${
                      i === 22 ? "bg-primary/60" : "bg-success/70"
                    }`}
                  />
                ))}
              </div>
              <div className="mono-label mt-2 flex justify-between text-muted-foreground">
                <span>30 days</span>
                <span>1 degraded minute</span>
              </div>
            </div>
          </div>

          {/* 4 — Wide fleet block */}
          <div className="card-lift rounded-xl border border-border bg-navy p-6 text-navy-foreground lg:col-span-7">
            <div className="flex h-full flex-col justify-between gap-6 md:flex-row md:items-center">
              <div>
                <span className="flex h-9 w-9 items-center justify-center rounded-md bg-white/10 text-navy-foreground">
                  <Layers className="h-4.5 w-4.5" />
                </span>
                <h3 className="mt-3 text-lg font-semibold">
                  GPON, EPON &amp; Ethernet CPE managed as one fleet
                </h3>
                <p className="mt-2 max-w-sm text-sm leading-relaxed text-navy-muted">
                  Mixed-technology, mixed-vendor networks stay unified — one
                  inventory, one provisioning pipeline, one dashboard.
                </p>
              </div>
              <div className="shrink-0 rounded-lg border border-line-dark bg-white/5 px-6 py-5 text-center">
                <p className="text-lg font-bold leading-snug">
                  Zero hidden licensing fees.
                  <br />
                  <span className="text-navy-muted">Ever.</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export { PROTOCOLS };
