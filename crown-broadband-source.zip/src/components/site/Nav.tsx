import crownLogo from "@/assets/crown-logo.png.asset.json";

const NAV_ANCHORS = [
  { label: "Platform", href: "#platform" },
  { label: "Architecture", href: "#architecture" },
  { label: "Pricing", href: "#pricing" },
  { label: "Contact", href: "#contact" },
];

export function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <a href="#top" className="flex items-center gap-2.5">
          <img src={crownLogo.url} alt="Crown Broadband" className="h-10 w-auto" />
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
          {NAV_ANCHORS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-muted-foreground transition-colors duration-150 hover:text-foreground"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <a
            href="mailto:crownbroadband.in@gmail.com"
            className="hidden text-sm font-medium text-muted-foreground transition-colors duration-150 hover:text-foreground sm:inline-block"
          >
            crownbroadband.in@gmail.com

          </a>
          <a
            href="#contact"
            className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors duration-150 hover:bg-primary-hover"
          >
            Get Started
          </a>
        </div>
      </div>
    </header>
  );
}
