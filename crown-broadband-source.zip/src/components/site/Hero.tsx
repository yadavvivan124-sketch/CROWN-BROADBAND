import { useEffect, useState } from "react";
import { Activity, CheckCircle2, Wifi } from "lucide-react";

function useElapsedSeconds() {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, []);
  return seconds;
}

function formatUptime(baseDays: number, extraSeconds: number) {
  const total = baseDays * 86400 + extraSeconds;
  const d = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d}d ${pad(h)}:${pad(m)}:${pad(s)}`;
}

const SPECS: { label: string; value: React.ReactNode }[] = [
  { label: "ONT Model", value: <span className="font-semibold">Nokia XS-010X-Q</span> },
  { label: "Serial No", value: <span className="font-mono text-[13px] font-medium">ZGC2B3A7K41E</span> },
  {
    label: "PPPoE Status",
    value: (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-success-soft px-2 py-0.5 text-xs font-semibold text-success">
        <CheckCircle2 className="h-3 w-3" /> Connected
      </span>
    ),
  },
  {
    label: "Optical Rx Power",
    value: (
      <span className="font-mono text-[13px] font-semibold tabular-nums">
        -19.4 dBm
      </span>
    ),
  },
  {
    label: "Wi-Fi",
    value: (
      <span className="inline-flex items-center gap-1.5 text-sm font-semibold">
        <Wifi className="h-3.5 w-3.5 text-primary" /> 6 — Active 2.4/5 GHz
      </span>
    ),
  },
];

export function Hero() {
  const seconds = useElapsedSeconds();

  return (
    <section id="top" className="relative overflow-hidden bg-background">
      <div className="bg-grid absolute inset-0" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-6xl gap-14 px-6 pb-20 pt-16 md:pt-24 lg:grid-cols-2 lg:items-center lg:gap-12">
        <div>
          <div className="inline-flex items-center gap-2.5 rounded-full border border-border bg-card px-3.5 py-1.5">
            <span className="animate-live-dot h-2 w-2 rounded-full bg-success" />
            <span className="mono-label text-muted-foreground">
              Carrier-Grade ACS • TR-069 / CWMP Provisioning
            </span>
          </div>

          <h1 className="mt-6 text-4xl font-extrabold leading-[1.1] tracking-tight text-foreground md:text-[3.25rem]">
            Carrier-Grade ACS &amp; TR-069 Device Management for ISPs.
          </h1>

          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
            Streamline device provisioning, automate CWMP workflows, and scale
            network operations with transparent, predictable pricing.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href="#pricing"
              className="inline-flex items-center rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-sm transition-colors duration-150 hover:bg-primary-hover"
            >
              View Plans
            </a>
            <a
              href="#contact"
              className="inline-flex items-center rounded-md border border-border bg-card px-5 py-3 text-sm font-semibold text-foreground transition-colors duration-150 hover:border-foreground/25 hover:bg-accent"
            >
              Contact Sales
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-border pt-6">
            {[
              "Zero Hidden Licensing Fees",
              "Carrier-Grade Reliability",
              "Dedicated L2/L3 Support",
            ].map((badge) => (
              <span
                key={badge}
                className="inline-flex items-center gap-2 text-[13px] font-medium text-muted-foreground"
              >
                <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
                {badge}
              </span>
            ))}
          </div>
        </div>

        {/* ACS telemetry card */}
        <div className="relative">
          <div className="card-lift rounded-xl border border-border bg-card shadow-[0_24px_60px_-30px_rgba(15,23,42,0.25)]">
            <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
              <span className="mono-label flex items-center gap-2 text-muted-foreground">
                <Activity className="h-3.5 w-3.5 text-primary" />
                ACS Telemetry
              </span>
              <span className="inline-flex items-center gap-2 rounded-full bg-success-soft px-2.5 py-1">
                <span className="animate-live-dot h-1.5 w-1.5 rounded-full bg-success" />
                <span className="mono-label text-success">Live</span>
              </span>
            </div>

            <dl className="divide-y divide-border">
              {SPECS.map((spec) => (
                <div
                  key={spec.label}
                  className="flex items-center justify-between px-5 py-3.5"
                >
                  <dt className="mono-label text-muted-foreground">{spec.label}</dt>
                  <dd className="text-sm tabular-nums">{spec.value}</dd>
                </div>
              ))}
              <div className="flex items-center justify-between bg-secondary/60 px-5 py-3.5">
                <dt className="mono-label text-muted-foreground">Uptime</dt>
                <dd className="font-mono text-[13px] font-semibold tabular-nums text-foreground">
                  {formatUptime(12, 16211 + seconds)}
                </dd>
              </div>
            </dl>

            <div className="flex items-center justify-between border-t border-border px-5 py-3">
              <span className="mono-label text-muted-foreground">Last Inform</span>
              <span className="font-mono text-xs tabular-nums text-muted-foreground">
                {Math.max(2, 12 - (seconds % 12))}s ago
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
