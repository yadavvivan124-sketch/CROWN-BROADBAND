import { useMemo, useState } from "react";
import { CheckCircle2 } from "lucide-react";
import {
  SLIDER_MAX,
  SLIDER_MIN,
  TIERS,
  recommendTier,
} from "@/lib/pricing";

const INCLUSIONS = [
  "Zero hidden licensing fees",
  "TR-069 / CWMP standard compliance",
  "Dedicated L2/L3 support",
  "Migration assistance & onboarding",
  "Firmware orchestration updates",
  "Custom ACS UI access",
];

export function Pricing() {
  const [subscribers, setSubscribers] = useState(800);

  const recommended = useMemo(() => recommendTier(subscribers), [subscribers]);
  const enterpriseMonthly = subscribers > 2000 ? subscribers * 8 : null;
  const sliderPct =
    ((subscribers - SLIDER_MIN) / (SLIDER_MAX - SLIDER_MIN)) * 100;

  return (
    <section id="pricing" className="scroll-mt-20 bg-background py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="mono-label text-primary">Pricing</p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Priced by subscribers. Nothing hidden.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            Drag the slider to your subscriber count — we'll highlight the
            right plan for your network.
          </p>
        </div>

        {/* Slider */}
        <div className="mx-auto mt-12 max-w-3xl rounded-xl border border-border bg-card p-6 md:p-8">
          <div className="flex items-baseline justify-between">
            <span className="mono-label text-muted-foreground">Your Subscribers</span>
            <span className="font-mono text-2xl font-bold tabular-nums text-foreground">
              {subscribers.toLocaleString("en-IN")}
              {subscribers >= SLIDER_MAX ? "+" : ""}
            </span>
          </div>
          <input
            type="range"
            min={SLIDER_MIN}
            max={SLIDER_MAX}
            step={50}
            value={subscribers}
            onChange={(e) => setSubscribers(Number(e.target.value))}
            aria-label="Subscriber count"
            className="pricing-slider mt-5 w-full"
            style={{ "--pct": `${sliderPct}%` } as React.CSSProperties}
          />
          <div className="mono-label mt-2 flex justify-between text-muted-foreground">
            <span>400</span>
            <span>2,000+</span>
          </div>
          <div className="mt-5 rounded-lg border border-primary/25 bg-primary-soft px-4 py-3 text-center">
            <span className="text-sm text-foreground">
              Recommended plan:{" "}
              <strong className="font-bold text-primary">
                {recommended.name}
              </strong>{" "}
              <span className="text-muted-foreground">
                ({recommended.subscribers})
              </span>
            </span>
          </div>
        </div>

        {/* Tier cards */}
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {TIERS.map((tier) => {
            const isActive = tier.id === recommended.id;
            const isEnterprise = tier.maxUsers === null;
            return (
              <div
                key={tier.id}
                className={`card-lift relative flex flex-col rounded-xl border p-5 transition-colors ${
                  isActive
                    ? "border-primary bg-card shadow-[0_16px_40px_-20px_rgba(37,99,235,0.35)]"
                    : "border-border bg-card"
                }`}
              >
                {isActive && (
                  <span className="absolute -top-2.5 left-4 rounded-full bg-primary px-2.5 py-0.5 text-[11px] font-semibold text-primary-foreground">
                    Recommended
                  </span>
                )}
                <p className="mono-label text-muted-foreground">{tier.name}</p>
                <p className="mt-2 text-sm font-semibold text-foreground">
                  {tier.subscribers}
                </p>

                <div className="mt-5 border-t border-border pt-4">
                  <p className="mono-label text-muted-foreground">Setup</p>
                  <p className="mt-1 font-mono text-lg font-semibold tabular-nums text-foreground">
                    {tier.setup}
                  </p>
                </div>
                <div className="mt-4 flex-1">
                  <p className="mono-label text-muted-foreground">Monthly</p>
                  <p className="mt-1 font-mono text-lg font-semibold tabular-nums text-foreground">
                    {tier.monthly}
                    <span className="ml-1 text-xs font-normal text-muted-foreground">
                      {isEnterprise ? "/ user /mo" : "/mo"}
                    </span>
                  </p>
                  {isEnterprise && enterpriseMonthly !== null && (
                    <p className="mono-label mt-2 text-primary">
                      ≈ ₹{enterpriseMonthly.toLocaleString("en-IN")} /mo
                    </p>
                  )}
                </div>
                <a
                  href="#contact"
                  className={`mt-6 inline-flex items-center justify-center rounded-md px-3 py-2 text-sm font-semibold transition-colors duration-150 ${
                    isActive
                      ? "bg-primary text-primary-foreground hover:bg-primary-hover"
                      : "border border-border text-foreground hover:bg-accent"
                  }`}
                >
                  Get Started
                </a>
              </div>
            );
          })}
        </div>

        {/* Inclusion banner */}
        <div className="mt-10 rounded-xl border border-border bg-navy px-6 py-6 text-navy-foreground md:px-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:gap-8">
            <p className="shrink-0 text-sm font-bold">
              All plans include
            </p>
            <ul className="flex flex-wrap gap-x-6 gap-y-2">
              {INCLUSIONS.map((inc) => (
                <li
                  key={inc}
                  className="inline-flex items-center gap-2 text-[13px] font-medium text-navy-muted"
                >
                  <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
                  {inc}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
