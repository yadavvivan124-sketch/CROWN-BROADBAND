import { createFileRoute } from "@tanstack/react-router";

import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { Ticker } from "@/components/site/Ticker";
import { Platform } from "@/components/site/Platform";
import { Architecture } from "@/components/site/Architecture";
import { Pricing } from "@/components/site/Pricing";
import { ContactFooter } from "@/components/site/ContactFooter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "Crown Broadband — Carrier-Grade ACS & TR-069 Device Management for ISPs",
      },
      {
        name: "description",
        content:
          "Carrier-grade ACS & TR-069/CWMP device management for ISPs. Zero-touch provisioning, multi-vendor CPE control and transparent, subscriber-based pricing.",
      },
      {
        property: "og:title",
        content: "Crown Broadband — Carrier-Grade ACS & TR-069 Device Management for ISPs",
      },
      {
        property: "og:description",
        content:
          "Streamline device provisioning, automate CWMP workflows, and scale network operations with transparent, predictable pricing.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Crown Broadband — Carrier-Grade ACS & TR-069 Device Management" },
      {
        name: "twitter:description",
        content:
          "Carrier-grade ACS & TR-069/CWMP device management for ISPs. Zero-touch provisioning and transparent, subscriber-based pricing.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <main>
        <Hero />
        <Ticker />
        <Platform />
        <Architecture />
        <Pricing />
      </main>
      <ContactFooter />
    </div>
  );
}
